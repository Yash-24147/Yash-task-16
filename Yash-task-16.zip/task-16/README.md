
Student Records

About

This is a simple Student Records Web Application. It displays student information in card format and allows users to search for students by name.

Technologies Used

HTML

CSS

JavaScript

Features

Displays student records in card format

Shows student name, marks, class, and address

Provides a search box to search students by name

Updates student records while typing

Displays matching student records

Shows a message when no student is found

Uses map function to display student cards

Uses filter function to search student names

Operations Performed

1 Display Student Records

Displays all student details in separate cards.

2 Search Students

Allows users to search students by entering their names.

3 Filter Students

Filters student records using the filter function.

4 Dynamic Display

Updates the displayed cards whenever the search input changes.

How to Run

Create a folder named Student Records.

Create index.html, style.css, and script.js files.

Add the respective code to each file.

Keep all files in the same folder.

Open index.html in a browser.

Project Files

index.html

style.css

script.js

README.md

Author

Yash


const students = [
    {
        name: "Yash",
        marks: 85,
        class: "MCA",
        address: "Ludhiana"
    },
    {
        name: "Rahul",
        marks: 78,
        class: "BCA",
        address: "Delhi"
    },
    {
        name: "Priya",
        marks: 92,
        class: "MCA",
        address: "Chandigarh"
    },
    {
        name: "Aman",
        marks: 75,
        class: "BBA",
        address: "Amritsar"
    },
    {
        name: "Neha",
        marks: 88,
        class: "BCA",
        address: "Jalandhar"
    },
    {
        name: "Rohit",
        marks: 81,
        class: "MCA",
        address: "Patiala"
    },
    {
         name: "Jhon Cena",
        marks: 81,
        class: "MCA",
        address: "USA"
    },
    {
         name: "Undertaker",
        marks: 81,
        class: "MCA",
        address: "RIP"
    }
];

const studentContainer = document.getElementById("studentContainer");
const search = document.getElementById("search");

function displayStudents(data) {

    if (data.length === 0) {
        studentContainer.innerHTML = "<p class='no-result'>No student found.</p>";
        return;
    }

    studentContainer.innerHTML = data.map((student) => {
        return `
            <div class="student-card">
                <h2>${student.name}</h2>
                <p>Marks: ${student.marks}</p>
                <p>Class: ${student.class}</p>
                <p>Address: ${student.address}</p>
            </div>
        `;
    }).join("");
}

displayStudents(students);

search.addEventListener("input", function () {

    const searchValue = search.value.toLowerCase();

    const filteredStudents = students.filter((student) => {
        return student.name.toLowerCase().includes(searchValue);
    });

    displayStudents(filteredStudents);
});
